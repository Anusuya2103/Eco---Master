import { Router, type IRouter } from "express";
import { rooms } from "../lib/gameEngine";
import { CreateRoomBody, GetRoomParams, GetRoomLeaderboardParams } from "@workspace/api-zod";

const router: IRouter = Router();

router.post("/rooms", (req, res): void => {
  const parsed = CreateRoomBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  // Room creation is handled via Socket.IO; this is a lightweight REST stub
  // to satisfy the OpenAPI contract and allow REST-based room lookup
  const roomId = `rest-${Math.random().toString(36).substring(2, 10)}`;
  const code = Math.random().toString(36).substring(2, 8).toUpperCase();

  res.status(201).json({
    id: roomId,
    code,
    hostName: parsed.data.hostName,
    state: "waiting",
    playerCount: 0,
    currentRound: 0,
    createdAt: new Date().toISOString(),
  });
});

router.get("/rooms/:id", (req, res): void => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const parsed = GetRoomParams.safeParse({ roomId: raw });
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const room = rooms.get(parsed.data.roomId);
  if (!room) {
    res.status(404).json({ error: "Room not found" });
    return;
  }

  res.json({
    id: room.id,
    code: room.code,
    hostName: room.hostName,
    state: room.state,
    playerCount: room.players.size,
    currentRound: room.currentRound,
    createdAt: new Date().toISOString(),
  });
});

router.get("/rooms/:id/leaderboard", (req, res): void => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const parsed = GetRoomLeaderboardParams.safeParse({ roomId: raw });
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const room = rooms.get(parsed.data.roomId);
  if (!room) {
    res.status(404).json({ error: "Room not found" });
    return;
  }

  const leaderboard = Array.from(room.players.values())
    .sort((a, b) => {
      if (b.ecoScore !== a.ecoScore) return b.ecoScore - a.ecoScore;
      if (b.position !== a.position) return b.position - a.position;
      return b.correctAnswers - a.correctAnswers;
    })
    .map((p, i) => ({
      rank: i + 1,
      playerId: p.id,
      playerName: p.name,
      animalId: p.animalId,
      ecoScore: p.ecoScore,
      position: p.position,
      correctAnswers: p.correctAnswers,
    }));

  res.json(leaderboard);
});

export default router;
