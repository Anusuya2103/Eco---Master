import { useEffect, useRef } from "react";
import {
  drawAnimalPortrait,
  drawLightningBolt,
  drawStar,
  drawFinishFlag,
  drawZoneDecoration,
} from "../lib/animal-draw";

interface Animal {
  id: string;
  emoji: string;
  colorPrimary?: string;
  colorSecondary?: string;
}

interface Player {
  id: string;
  name: string;
  animalId: string;
  position: number;
  ecoScore?: number;
  isHost?: boolean;
  streak?: number;
}

interface GameBoardProps {
  players: Player[];
  animals?: Animal[];
  highlightPlayerId?: string;
}

const COLS = 10;
const TILES = 100;

function getZoneColors(i: number) {
  if (i < 20) return { bg: "#14532d", accent: "#22c55e", label: "Forest" };
  if (i < 40) return { bg: "#1e3a5f", accent: "#3b82f6", label: "Ocean" };
  if (i < 60) return { bg: "#78350f", accent: "#f59e0b", label: "Desert" };
  if (i < 80) return { bg: "#1f2937", accent: "#9ca3af", label: "Human" };
  return { bg: "#134e2a", accent: "#4ade80", label: "Restore" };
}

function isHazard(i: number) { return i > 0 && i % 7 === 0 && i % 11 !== 0; }
function isBonus(i: number) { return i > 0 && i % 11 === 0; }

function getTileCenter(i: number, tileW: number, tileH: number, padX: number, padY: number) {
  const row = Math.floor(i / COLS);
  const col = row % 2 === 0 ? i % COLS : (COLS - 1) - (i % COLS);
  return {
    x: padX + col * tileW + tileW / 2,
    y: padY + row * tileH + tileH / 2,
  };
}

function drawRoundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
  ctx.closePath();
}

export function GameBoard({ players, animals = [], highlightPlayerId }: GameBoardProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);
  const playersRef = useRef<Player[]>([]);
  const animalsRef = useRef<Animal[]>([]);
  const highlightRef = useRef<string | undefined>(undefined);

  // Per-player animated state: { x, y, scale, bounceTimer, lastPos }
  const animState = useRef<Map<string, {
    x: number; y: number; scale: number; bounceTimer: number; lastPos: number;
  }>>(new Map());

  useEffect(() => { playersRef.current = players; }, [players]);
  useEffect(() => { animalsRef.current = animals; }, [animals]);
  useEffect(() => { highlightRef.current = highlightPlayerId; }, [highlightPlayerId]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const render = (timestamp: number) => {
      const dt = Math.min((timestamp - lastTimeRef.current) / 1000, 0.05);
      lastTimeRef.current = timestamp;
      const t = timestamp / 1000;

      const rect = canvas.getBoundingClientRect();
      const W = Math.floor(rect.width);
      const H = Math.floor(rect.height);
      if (canvas.width !== W || canvas.height !== H) {
        canvas.width = W;
        canvas.height = H;
      }

      // Layout
      const margin = 6;
      const tileW = (W - margin * 2) / COLS;
      const rows = TILES / COLS;
      const tileH = (H - margin * 2) / rows;
      const padX = margin;
      const padY = margin;
      const tw = tileW * 0.88;
      const th = tileH * 0.88;
      const gap = tileW * 0.06;
      const rr = Math.min(tw, th) * 0.18;
      const fontSize = Math.max(7, Math.min(tileW, tileH) * 0.22);

      // Pre-compute tile centers
      const centers: { x: number; y: number }[] = [];
      for (let i = 0; i < TILES; i++) centers.push(getTileCenter(i, tileW, tileH, padX, padY));

      // ── Background ──────────────────────────────────────────────────────────
      const bgGrad = ctx.createLinearGradient(0, 0, 0, H);
      bgGrad.addColorStop(0, "#0c1a10");
      bgGrad.addColorStop(1, "#08121e");
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, W, H);

      // ── Zone labels (faint) ─────────────────────────────────────────────────
      const zoneNames = ["FOREST", "OCEAN", "DESERT", "HUMAN IMPACT", "RESTORATION"];
      zoneNames.forEach((name, zi) => {
        const zone = getZoneColors(zi * 20);
        ctx.save();
        ctx.font = `bold ${Math.max(9, fontSize * 0.9)}px sans-serif`;
        ctx.fillStyle = zone.accent + "55";
        ctx.textAlign = "center";
        // Place label on the right side of even rows, left of odd rows
        const startRow = zi * 2;
        const cy = padY + startRow * tileH + tileH;
        const cx = W / 2;
        ctx.fillText(name, cx, cy - tileH * 0.1);
        ctx.restore();
      });

      // ── Dashed path between tiles ───────────────────────────────────────────
      ctx.save();
      ctx.setLineDash([3, 6]);
      ctx.strokeStyle = "rgba(255,255,255,0.10)";
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(centers[0].x, centers[0].y);
      for (let i = 1; i < TILES; i++) ctx.lineTo(centers[i].x, centers[i].y);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();

      // ── Draw tiles ──────────────────────────────────────────────────────────
      for (let i = 0; i < TILES; i++) {
        const c = centers[i];
        const zone = getZoneColors(i);
        const x0 = c.x - tw / 2;
        const y0 = c.y - th / 2;
        const hz = isHazard(i);
        const bn = isBonus(i);
        const isStart = i === 0;
        const isFinish = i === TILES - 1;

        // Tile glow
        if (hz) {
          ctx.save();
          ctx.shadowColor = "#ef4444";
          ctx.shadowBlur = 8;
        } else if (bn) {
          ctx.save();
          ctx.shadowColor = "#fbbf24";
          ctx.shadowBlur = 8;
        } else if (isStart || isFinish) {
          ctx.save();
          ctx.shadowColor = isStart ? "#22c55e" : "#f59e0b";
          ctx.shadowBlur = 12;
        }

        // Tile fill
        drawRoundRect(ctx, x0 + gap / 2, y0 + gap / 2, tw - gap, th - gap, rr);
        const tileGrad = ctx.createLinearGradient(x0, y0, x0 + tw, y0 + th);
        tileGrad.addColorStop(0, zone.bg + "ee");
        tileGrad.addColorStop(1, zone.bg + "99");
        ctx.fillStyle = isStart ? "#14532dee" : isFinish ? "#78350fee" : tileGrad;
        ctx.fill();

        // Tile border
        ctx.strokeStyle = hz
          ? "#ef4444cc"
          : bn
          ? "#fbbf24cc"
          : isStart
          ? "#22c55ecc"
          : isFinish
          ? "#f59e0bcc"
          : zone.accent + "55";
        ctx.lineWidth = hz || bn || isStart || isFinish ? 1.8 : 0.8;
        ctx.stroke();

        if (hz || bn || isStart || isFinish) ctx.restore();

        // Zone environmental art decoration (bottom-right corner)
        if (!isStart && !isFinish) {
          const zoneKey = zone.label === "Human" ? "human_impact"
            : zone.label === "Restore" ? "restoration"
            : zone.label.toLowerCase();
          drawZoneDecoration(ctx, zoneKey, x0, y0, tileW, tileH);
        }

        // Tile content
        ctx.save();
        ctx.font = `bold ${fontSize * 0.75}px monospace`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        if (isStart) {
          ctx.fillStyle = "#4ade80";
          ctx.font = `bold ${fontSize * 0.62}px sans-serif`;
          ctx.fillText("START", c.x, c.y);
        } else if (isFinish) {
          drawFinishFlag(ctx, c.x, c.y, Math.min(tileW, tileH) * 0.62);
        } else if (hz) {
          drawLightningBolt(ctx, c.x, c.y, Math.min(tileW, tileH) * 0.48, "#fca5a5");
        } else if (bn) {
          drawStar(ctx, c.x, c.y, Math.min(tileW, tileH) * 0.48, "#fde68a");
        } else {
          ctx.fillStyle = zone.accent + "88";
          ctx.fillText(String(i + 1), c.x, c.y);
        }
        ctx.restore();
      }

      // ── Update & draw animated player tokens ────────────────────────────────
      const currentPlayers = playersRef.current;
      const currentAnimals = animalsRef.current;
      const currentHighlight = highlightRef.current;

      // Group players by target tile for offset logic
      const byTile = new Map<number, Player[]>();
      currentPlayers.forEach((p) => {
        const tile = Math.max(0, Math.min(p.position, TILES - 1));
        if (!byTile.has(tile)) byTile.set(tile, []);
        byTile.get(tile)!.push(p);
      });

      currentPlayers.forEach((p, pIdx) => {
        const tile = Math.max(0, Math.min(p.position, TILES - 1));
        const target = centers[tile];

        // Multi-player on same tile: spread in a circle
        const group = byTile.get(tile)!;
        const myIdxInGroup = group.findIndex((g) => g.id === p.id);
        const groupCount = group.length;
        let offsetX = 0;
        let offsetY = 0;
        if (groupCount > 1) {
          const angle = (myIdxInGroup / groupCount) * Math.PI * 2 - Math.PI / 2;
          const radius = tileW * 0.18;
          offsetX = Math.cos(angle) * radius;
          offsetY = Math.sin(angle) * radius;
        }

        const tx = target.x + offsetX;
        const ty = target.y + offsetY;

        // Init or lerp animated state
        let state = animState.current.get(p.id);
        if (!state) {
          state = { x: tx, y: ty, scale: 1, bounceTimer: 0, lastPos: tile };
          animState.current.set(p.id, state);
        }

        // Detect position change → trigger bounce
        if (state.lastPos !== tile) {
          state.bounceTimer = 0.45;
          state.lastPos = tile;
        }

        // Lerp toward target (smooth follow)
        const lerpSpeed = 5;
        state.x += (tx - state.x) * Math.min(1, lerpSpeed * dt);
        state.y += (ty - state.y) * Math.min(1, lerpSpeed * dt);

        // Bounce scale animation
        if (state.bounceTimer > 0) {
          state.bounceTimer = Math.max(0, state.bounceTimer - dt);
          const progress = 1 - state.bounceTimer / 0.45;
          state.scale = 1 + 0.45 * Math.sin(progress * Math.PI);
        } else {
          state.scale = 1;
        }

        // Idle float (gentle bob)
        const floatY = Math.sin(t * 1.8 + pIdx * 1.3) * 1.8;

        const px = state.x;
        const py = state.y + floatY;
        const tokenR = Math.min(tileW, tileH) * 0.28 * state.scale;
        const isHighlighted = currentHighlight === p.id;

        // Shadow / glow
        ctx.save();
        ctx.shadowColor = isHighlighted ? "#fbbf24" : "rgba(0,0,0,0.6)";
        ctx.shadowBlur = isHighlighted ? 16 : 8;

        // Token background circle
        const animal = currentAnimals.find((a) => a.id === p.animalId);
        const primaryColor = animal?.colorPrimary || "#16a34a";
        ctx.beginPath();
        ctx.arc(px, py, tokenR, 0, Math.PI * 2);
        const tokenGrad = ctx.createRadialGradient(px - tokenR * 0.3, py - tokenR * 0.3, 0, px, py, tokenR);
        tokenGrad.addColorStop(0, primaryColor + "ff");
        tokenGrad.addColorStop(1, primaryColor + "99");
        ctx.fillStyle = tokenGrad;
        ctx.fill();

        // Token border
        ctx.strokeStyle = isHighlighted ? "#fbbf24" : "rgba(255,255,255,0.7)";
        ctx.lineWidth = isHighlighted ? 2.5 : 1.5;
        ctx.stroke();
        ctx.restore();

        // Animal portrait (drawn, no emoji)
        drawAnimalPortrait(ctx, p.animalId, animal?.colorPrimary, animal?.colorSecondary, px, py, tokenR * 0.96);

        // Player name label below token
        const nameY = py + tokenR + 2;
        const nameFontSize = Math.max(7, fontSize * 0.75);
        ctx.save();
        ctx.font = `bold ${nameFontSize}px sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "top";
        const nameWidth = ctx.measureText(p.name).width;
        // Name background pill
        ctx.fillStyle = "rgba(0,0,0,0.65)";
        drawRoundRect(ctx, px - nameWidth / 2 - 3, nameY - 1, nameWidth + 6, nameFontSize + 4, 3);
        ctx.fill();
        ctx.fillStyle = isHighlighted ? "#fde68a" : "#ffffff";
        ctx.fillText(p.name, px, nameY + 1);
        ctx.restore();
      });

      // Clean up state for players who left
      animState.current.forEach((_, id) => {
        if (!currentPlayers.find((p) => p.id === id)) animState.current.delete(id);
      });

      animFrameRef.current = requestAnimationFrame(render);
    };

    animFrameRef.current = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full block"
      style={{ touchAction: "none" }}
    />
  );
}
