class GameAudio {
  private ctx: AudioContext | null = null;
  private isMuted = false;
  private ambienceOsc: OscillatorNode | null = null;
  private ambienceGain: GainNode | null = null;

  init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    if (this.ctx) {
      if (this.isMuted) {
        this.ctx.suspend();
      } else {
        this.ctx.resume();
      }
    }
    return this.isMuted;
  }

  getMuted() {
    return this.isMuted;
  }

  playDing() {
    if (this.isMuted || !this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(440, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(880, this.ctx.currentTime + 0.1);
    
    gain.gain.setValueAtTime(0, this.ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.5, this.ctx.currentTime + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.5);
    
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.5);
  }

  playBuzz() {
    if (this.isMuted || !this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(150, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(100, this.ctx.currentTime + 0.3);
    
    gain.gain.setValueAtTime(0, this.ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.5, this.ctx.currentTime + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.3);
    
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.3);
  }

  playHazard() {
    if (this.isMuted || !this.ctx) return;
    const freqs = [329.63, 261.63, 220.00]; // E4, C4, A3 (A minor desc)
    freqs.forEach((freq, i) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = "square";
      osc.frequency.setValueAtTime(freq, this.ctx!.currentTime + i * 0.1);
      
      gain.gain.setValueAtTime(0, this.ctx!.currentTime + i * 0.1);
      gain.gain.linearRampToValueAtTime(0.2, this.ctx!.currentTime + i * 0.1 + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.01, this.ctx!.currentTime + i * 0.1 + 0.4);
      
      osc.connect(gain);
      gain.connect(this.ctx!.destination);
      osc.start(this.ctx!.currentTime + i * 0.1);
      osc.stop(this.ctx!.currentTime + i * 0.1 + 0.4);
    });
  }

  playBonus() {
    if (this.isMuted || !this.ctx) return;
    const freqs = [261.63, 329.63, 392.00, 523.25]; // C4, E4, G4, C5 (C major asc)
    freqs.forEach((freq, i) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, this.ctx!.currentTime + i * 0.1);
      
      gain.gain.setValueAtTime(0, this.ctx!.currentTime + i * 0.1);
      gain.gain.linearRampToValueAtTime(0.3, this.ctx!.currentTime + i * 0.1 + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.01, this.ctx!.currentTime + i * 0.1 + 0.4);
      
      osc.connect(gain);
      gain.connect(this.ctx!.destination);
      osc.start(this.ctx!.currentTime + i * 0.1);
      osc.stop(this.ctx!.currentTime + i * 0.1 + 0.4);
    });
  }

  playTick() {
    if (this.isMuted || !this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = "square";
    osc.frequency.setValueAtTime(880, this.ctx.currentTime);
    gain.gain.setValueAtTime(0, this.ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.15, this.ctx.currentTime + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.12);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.12);
  }

  playFanfare() {
    if (this.isMuted || !this.ctx) return;
    // C major victory arpeggio: C4 E4 G4 C5 E5 C5 G4
    const notes = [261.63, 329.63, 392.00, 523.25, 659.25, 523.25, 392.00];
    notes.forEach((freq, i) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      const t = this.ctx!.currentTime + i * 0.13;
      osc.type = "triangle";
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0, t);
      gain.gain.linearRampToValueAtTime(0.4, t + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);
      osc.connect(gain);
      gain.connect(this.ctx!.destination);
      osc.start(t);
      osc.stop(t + 0.5);
    });
  }

  playCountdownUrgent() {
    if (this.isMuted || !this.ctx) return;
    // Two rapid high beeps
    [0, 0.15].forEach((offset) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      const t = this.ctx!.currentTime + offset;
      osc.type = "square";
      osc.frequency.setValueAtTime(1046.5, t);
      gain.gain.setValueAtTime(0, t);
      gain.gain.linearRampToValueAtTime(0.2, t + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
      osc.connect(gain);
      gain.connect(this.ctx!.destination);
      osc.start(t);
      osc.stop(t + 0.1);
    });
  }

  setAmbience(zone: string) {
    if (this.isMuted || !this.ctx) return;
    
    if (this.ambienceOsc) {
      this.ambienceGain?.gain.linearRampToValueAtTime(0.01, this.ctx.currentTime + 1);
      this.ambienceOsc.stop(this.ctx.currentTime + 1);
    }

    this.ambienceOsc = this.ctx.createOscillator();
    this.ambienceGain = this.ctx.createGain();
    
    this.ambienceOsc.connect(this.ambienceGain);
    this.ambienceGain.connect(this.ctx.destination);
    
    this.ambienceGain.gain.setValueAtTime(0.01, this.ctx.currentTime);
    this.ambienceGain.gain.linearRampToValueAtTime(0.1, this.ctx.currentTime + 2);

    switch (zone) {
      case "forest":
        this.ambienceOsc.type = "triangle";
        this.ambienceOsc.frequency.setValueAtTime(100, this.ctx.currentTime);
        break;
      case "ocean":
        this.ambienceOsc.type = "sine";
        this.ambienceOsc.frequency.setValueAtTime(50, this.ctx.currentTime);
        break;
      case "desert":
        this.ambienceOsc.type = "sawtooth";
        this.ambienceOsc.frequency.setValueAtTime(80, this.ctx.currentTime);
        break;
      case "human_impact":
        this.ambienceOsc.type = "square";
        this.ambienceOsc.frequency.setValueAtTime(60, this.ctx.currentTime);
        break;
      case "restoration":
        this.ambienceOsc.type = "sine";
        this.ambienceOsc.frequency.setValueAtTime(120, this.ctx.currentTime);
        break;
      default:
        this.ambienceOsc.type = "sine";
        this.ambienceOsc.frequency.setValueAtTime(0, this.ctx.currentTime);
    }
    
    this.ambienceOsc.start();
  }
}

export const audio = new GameAudio();
